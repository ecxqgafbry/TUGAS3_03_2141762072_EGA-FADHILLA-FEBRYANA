/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan2;

/**
 *
 * @author ASUS
 */
import java.util.Scanner;
public class TestKoperasi {
    public static void main(String[] args){ 
    Scanner sc = new Scanner(System.in);
    Anggota donny = new Anggota("111333444", "Donny", 5000000); 	 
    System.out.println("Nama Anggota: " + donny.getNama()); 
    System.out.println("Limit Pinjaman: " + donny.getLimitPinjaman());  

    System.out.println("\nMasukkan uang yang dipinjam");
    int pinjam = sc.nextInt();
    donny.pinjam(pinjam); 
    System.out.println("Jumlah pinjaman saat ini: " + donny.getJumlahPinjaman());  

    System.out.println("\nMasukkan uang yang dipinjam");
    int pinjaml = sc.nextInt();
    donny.pinjam(pinjaml); 
    System.out.println("Jumlah pinjaman saat ini: " + donny.getJumlahPinjaman());  

    //System.out.println("\nMembayar angsuran 3.000.000"); 
    //donny.angsur(3000000); 
    //System.out.println("Jumlah pinjaman saat ini: " + donny.getJumlahPinjaman()); 	

    System.out.println("\nMasukkan angsuran ");
    int angsurl = sc.nextInt();
    donny.angsur(angsurl);
    System.out.println("Jumlah pinjam saat ini : " + donny.getJumlahPinjaman());

    
    System.out.println("\nMasukkan angsuran ");
    int angsur = sc.nextInt();
    donny.angsur(angsurl);
    System.out.println("Jumlah pinjam saat ini : " + donny.getJumlahPinjaman());
    
    }
}
